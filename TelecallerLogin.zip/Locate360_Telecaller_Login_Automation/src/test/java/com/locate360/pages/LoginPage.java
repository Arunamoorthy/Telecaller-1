package com.locate360.pages;

import com.locate360.base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LoginPage extends BaseClass {
    // Robust locators based on the visible Telecaller Panel login screen.
    private final By email = By.xpath("//input[@type='email' or contains(translate(@placeholder,'EMAIL','email'),'email')]");
    private final By password = By.xpath("//input[@type='password']");
    private final By signIn = By.xpath("//button[contains(normalize-space(.),'Sign In')]");
    private final By forgotPassword = By.xpath("//*[self::a or self::button][contains(normalize-space(.),'Forgot Password')]");

    public void enterEmail(String value) { WebElement e = driver.findElement(email); e.clear(); e.sendKeys(value); }
    public void enterPassword(String value) { WebElement e = driver.findElement(password); e.clear(); e.sendKeys(value); }
    public void clickSignIn() { driver.findElement(signIn).click(); }
    public boolean isPasswordMasked() { return "password".equalsIgnoreCase(driver.findElement(password).getAttribute("type")); }
    public boolean isForgotPasswordDisplayed() { return driver.findElement(forgotPassword).isDisplayed(); }
    public String currentUrl() { return driver.getCurrentUrl(); }
}
